default_app_config = 'wallet.apps.WalletConfig'
