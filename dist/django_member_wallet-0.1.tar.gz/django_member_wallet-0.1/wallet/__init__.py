#default_app_config = 'wechat_member_wallet.apps.WechatMemberWalletConfig'
