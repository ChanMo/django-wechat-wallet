#!/usr/bin/python
# vim: set fileencoding=utf-8 :
from django.apps import AppConfig

class WechatMemberWalletConfig(AppConfig):
    name = u'wallet',
    verbose_name = u'钱包'
